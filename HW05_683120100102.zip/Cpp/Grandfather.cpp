#include <iostream>
using namespace std;

class GrandFather{

    public:
    string name;
    int age ;

    GrandFather(string name, int age):name(name), age(age){}

    GrandFather(){
        name = "Unknown";
        age = 0;
    }
     void infoFamilyGrandFather(){
        cout << "GrandFather Name: " << name << ", Age: " << age << endl;

    }
    class Uncle{
        
        public:
        string name;
        int age ;

        Uncle(string name , int age):name(name), age(age){}

        Uncle(){
            name = "Unknown";
            age = 0;
        }
        void infoFamilyUncle(){
            cout << "Uncle Name: " << name << ", Age: " << age << endl;

        }
    };

    class Father{
        
        public:
        string name;
        int age ;

        Father(string name , int age):name(name), age(age){}

        Father(){
            name = "Unknown";
            age = 0;
        }
        void infoFamilyFather(){
            cout << "Father Name: " << name << ", Age: " << age << endl;

        }
        class Brother{
            public :
            string name;
            int age ;
            Brother(string name , int age):name(name),age(age){}

            Brother(){
                name = "Unknown";
                age = 0;
            }

            void infoFamilyBrother(){
                cout << " Brother Name:"<< name << "Age: " << age <<endl;
            }
            };
            
            class Niece{
                public :
                string name;
                int age ;

                Niece(string name , int age):name(name),age(age){}

                Niece(){
                    name = "Unknown";
                    age = 0;
                }

                void infoFamilyNiece(){
                    cout << " Niece Name :"<< name << "Age :"<< age << endl;
                }
            };
        class Me{
            public:
            string name;
            int age;

            Me(string name , int age):name(name),age(age){}

            Me(){
                name = "Unknown";
                age = 0;
            }
            void infoFamilyMe(){
                cout << " Me Name :"<< name << " Age :"<< age << endl;
            }

            class Mydog{
                public:
                string name;
                int age;

                Mydog(string name, int age):name(name),age(age){}

                Mydog(){

                    name = "Unknown";
                    age = 0;
                }

                void infoFamilymydog(){
                    cout << "Mydog Namr :"<<name <<"Age :"<<age << endl;
                }
            };

        };
    };
};



int main(){
    GrandFather gf ("Poom",19);
    GrandFather g1;
    gf.infoFamilyGrandFather();
    g1.infoFamilyGrandFather();

    GrandFather::Uncle u1("john",45);
    GrandFather::Uncle u2;
    u1.infoFamilyUncle();   
    u2.infoFamilyUncle();

    GrandFather::Father f1("mike",50);
    GrandFather::Father f2;
    f1.infoFamilyFather();
    f2.infoFamilyFather();

    GrandFather::Father::Brother b1 ("tie ",19);
    GrandFather::Father::Brother b2 ;
    b1.infoFamilyBrother();
    b2.infoFamilyBrother();

    GrandFather::Father::Niece n1 ("lily",5);
    GrandFather::Father::Niece n2 ;
    n1.infoFamilyNiece();
    n2.infoFamilyNiece();

    GrandFather::Father::Me m1 ("alex",20);
    GrandFather::Father::Me m2 ;
    m1.infoFamilyMe();
    m2.infoFamilyMe();

    GrandFather::Father::Me::Mydog d1 ("buddy",3);
    GrandFather::Father::Me::Mydog d2 ;
    d1.infoFamilymydog();
    d2.infoFamilymydog();
    return 0;

};