using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Grandfather
{
    public static class Program
    {
        static void Main(string[] args)
        {
            var gf = new Grandfather("john",70);
            gf.infoGrandfather();

            var u1 = new Grandfather.Uncle("mike", 50);
            u1.infoUncle();

            var f1 = new Grandfather.Father("robert", 45);
            f1.infoFather();

            var b1 = new Grandfather.Father.Brother("david", 40);
            b1.infoBrother();

            var n1 = new Grandfather.Father.Brother.Niece("sarah", 15);
            n1.infoNiece();

            var m1 = new Grandfather.Father.Me("alex", 20);
            m1.infoMe();

            var d1 = new Grandfather.Father.Me.Mydog("buddy", 3);
            d1.infoMydog();


        }


    }
    public class Grandfather
    {
        public string name;
        public int age;

        public Grandfather(string name ,int age)
        {
            this.name = name;
            this.age = age;
        }
        public void infoGrandfather()
        {
             Console.WriteLine($"Grandfather Name: {name}, Age: {age}");
        
        }


     public class Uncle
        {
            public string name;
            public int age;

            public Uncle (string name , int age)
            {
                this.name = name;
                this.age = age;
            }
            public void infoUncle()
            {
                Console.WriteLine($"Uncle Name : {name},Age : {age}");
            }
        }
    public class Father
        {
            public string name;
            public int age ;

            public Father(string name, int age)
            {
                this.name = name;
                this.age = age;
            }

            public void infoFather()
            {
               Console.WriteLine($"Father Name: {name}, Age: {age}");
            }
        public class Brother
        {
            public string name;
            public int age;

            public Brother(string name, int age)
            {
                this.name = name;
                this.age = age;
            }
            public void infoBrother()
            {
                Console.WriteLine($"Brother Name: {name}, Age: {age}");
            }
            public class Niece
                {
                    public string name;
                    public int age;

                    public Niece(string name, int age)
                    {
                        this.name = name;
                        this.age = age;
                    }
                    public void infoNiece()
                    {
                        Console.WriteLine($"Niece Name: {name}, Age: {age}");
                    }
                }



        }
        public class Me
            {
                public string name;
                public int age ;

                public Me(string name, int age)
                {
                    this.name = name;
                    this.age = age;
                }
                public void infoMe()
                {
                    Console.WriteLine($"My Name: {name}, Age: {age}");
                }


                public class Mydog
                {
                    public string name; 
                    public int age;

                    public Mydog(string name,int age)
                    {
                        this.name = name;
                        this.age = age;
                    }
                    public void infoMydog()
                    {
                       Console.WriteLine($"MY Dog Name:{name},Age : {age}");
                    }
                }
            }

    }


}
}