public class Main
{
    public static void main(String[] args) {
        Grandfather gf = new Grandfather("John", 75);
        gf.infoGF();

        Grandfather.Uncle u = gf.new Uncle("Mike", 50);
        u.infoU();

        Grandfather.Father f = gf.new Father("David", 48);
        f.infoF();

        Grandfather.Father.Brother b = f.new Brother("Chris", 25);
        b.infoB();

        Grandfather.Father.Brother.Niece n = b.new Niece("Sophia", 5);
        n.infoN();

        Grandfather.Father.Me me = f.new Me("Alex", 22);
        me.infoMe();

        Grandfather.Father.Me.Mydog dog = me.new Mydog("Buddy", 3);
        dog.infoDog();
    }
}
class Grandfather{
    public String name;
    public int age;

    public Grandfather(String name, int age){
        this.name = name;
        this.age = age;
    }

    public void infoGF(){
        System.out.printf("Grandfather Name: %s\n",name);
        System.out.printf("Grandfather Age: %d\n",age);

    }
    class Uncle{
        public String name;
        public int age;

        public Uncle(String name, int age){
            this.name = name;
            this.age = age;
        }

        public void infoU(){
            System.out.printf("Uncle Name: %s\n",name);
            System.out.printf("Uncle Age: %d\n",age);

        }

    }

        class Father{
            public String name;
            public int age;

            public Father(String name, int age){
                this.name = name;
                this.age = age;
            }

            public void infoF(){
                System.out.printf("Father Name: %s\n",name);
                System.out.printf("Father Age: %d\n",age);

            }
    class Brother{
        public String name;
        public int age;

        public Brother(String name, int age){
            this.name = name;
            this.age = age;
        }

        public void infoB(){
            System.out.printf("Brother Name: %s\n",name);
            System.out.printf("Brother Age: %d\n",age);

        }
        class Niece{
            public String name;
            public int age;

            public Niece(String name, int age){
                this.name = name;
                this.age = age;
            }

            public void infoN(){
                System.out.printf("Niece Name: %s\n",name);
                System.out.printf("Niece Age: %d\n",age);

            }
        }
    }

    class Me{
        public String name;
        public int age;

        public Me(String name, int age){
            this.name = name;
            this.age = age;
        }

        public void infoMe(){
            System.out.printf("Me Name: %s\n",name);
            System.out.printf("Me Age: %d\n",age);

        }
        
        class Mydog{
            public String name;
            public int age;

            public Mydog(String name, int age){
                this.name = name;
                this.age = age;
            }

            public void infoDog(){
                System.out.printf("Mydog Name: %s\n",name);
                System.out.printf("Mydog Age: %d\n",age);

            }   
        }
    }

}
}