class Grandfather:
    def __init__(self,name ="" ,age=0):
        self.name = name
        self.age = age
    
    def infoFamilyGF(self):
        print ("Granfather Name :" + self.name)
        print ("Granfather Age :" + str(self.age))




    class Uncle:
        def __init__(self,name="",age=0):
            self.name = name
            self.age = age
       
        def infoFamilyUncle(self):
            print ("Uncle Name :" + self.name)
            print ("Uncle Age :" + str(self.age))

    class Father:
        def __init__(self,name="",age=0):
            self.name = name
            self.age = age

        
        def infoFamilyFather(self):
            print ("Father Name :" + self.name)
            print ("Father Age :" + str(self.age))

        class Brother:
            def __init__(self,name="",age=0):
                self.name = name
                self.age = age
            
            def infoFamilyBrother(self):
                print ("Brother Name :" + self.name)
                print ("Brother Age :" + str(self.age))
            
            class Niece:
                def __init__(self,name="",age=0):
                    self.name = name
                    self.age = age

                def infoFamilyNiece(self):
                    print ("Niece Name :" + self.name)
                    print ("NIece Age :"+ str(self.age))

        class Me:

            def __init__(self,name="",age=0):
                self.name = name
                self.age = age
            
            def infoFamilyMe(self):
                print ("Me Name :" + self.name)
                print ("Me Age :" + str(self.age))
            
            class Mydog:
                def __init__(self,name="",age=0):
                    self.name = name
                    self.age = age
                
               
                def infoFamilymydog(self):
                    print ("Mydog Name :" + self.name)
                    print ("Mydog Age :" + str(self.age))

if __name__ == "__main__":
    gf = Grandfather("Poom",19)
    g1 = Grandfather()
    gf.infoFamilyGF()
    g1.infoFamilyGF()

    u1 = gf.Uncle("UncleTom",45)
    u2 = gf.Uncle()
    u2.infoFamilyUncle()
    u1.infoFamilyUncle()

    f1 = gf.Father("Dad",40)
    f2 = gf.Father()
    f1.infoFamilyFather()
    f2.infoFamilyFather()

   
    b1 = f1.Brother("BrotherBob",18)
    b2 = f1.Brother()
    b2.infoFamilyBrother()
    b1.infoFamilyBrother()

    n1 = b1.Niece("NieceNina",5)
    n2 = b1.Niece()
    n2.infoFamilyNiece()
    n1.infoFamilyNiece()

    m1 = f1.Me("MyName",16)
    m2 = f1.Me()
    m2.infoFamilyMe()
    m1.infoFamilyMe()


    d2 = m1.Mydog("Doggy",3)
    d1 = m1.Mydog()
    d1.infoFamilymydog()
    d2.infoFamilymydog()